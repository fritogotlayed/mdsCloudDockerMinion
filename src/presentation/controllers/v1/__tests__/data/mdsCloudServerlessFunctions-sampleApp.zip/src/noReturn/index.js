const main = (input) => {
  return;
}

module.exports = {
  main,
};