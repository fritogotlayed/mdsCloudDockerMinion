const main = (input) => {
  return Object.assign({}, input, { three: 3 });
}

module.exports = {
  main,
};